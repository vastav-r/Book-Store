<div id="footer-wrap">
	<p id="legal">(c) 2016 Site,VIT UNIVERSITY.</p>
	</div>